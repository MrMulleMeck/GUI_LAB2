import 'package:flutter/material.dart';
import 'package:lab2/model/recipe_database/recipe.dart';
import 'package:lab2/ui_controller.dart';
import 'package:provider/provider.dart';

class RecipeListItem extends StatelessWidget {
  
  const RecipeListItem(this.recipe, {required this.onTap, super.key});

  final Recipe recipe;
  final void Function() onTap;

  @override
Widget build(BuildContext context) {
  var uiController = Provider.of<UIController>(context, listen: false);
    return Card(
    child: Container(
      height: 128,
      child: Row(
        children: [
        _image(recipe),
        Expanded(
          child: Column(
            children: [
              Text('Titel'),
              Text(
                recipe.description,
                overflow: TextOverflow.ellipsis, 
                maxLines: 2,
              ),
              Row(children: [Text('Lite mer grejer')]),
            ],
          ),
         ),
       ],
     ),
    ),
  );
  }
}